"""Only check_referral_criteria varies; safety and all other tools are fixed."""
from copy import deepcopy

TARGET = 'check_referral_criteria'


def descriptors(original, version='v2'):
    if version not in ('v1', 'v2'):
        raise ValueError('version must be v1 or v2')
    result = deepcopy(original)
    if version == 'v1':
        # Teammate's simple baseline, preserved from commit 92616d6.
        result[TARGET] = dict(name=TARGET,
            purpose='Check a referral against the requirements for its specialty.',
            when='Use after retrieving the referral and before making a decision.',
            args={'specialty': 'str, the referral specialty', 'referral_id': 'str, the referral id'},
            returns='Criteria information about the referral, such as flags, tests, department suitability and urgency.',
            failure='Returns None if the referral or specialty cannot be found.')
    else:
        result[TARGET].update(
            signature='check_referral_criteria(specialty: str, referral_id: str) -> Criteria | None',
            returns='{red_flag_term, right_department, missing_tests: [{code,name}]}; band and window_weeks appear ONLY when red_flag_term is null, right_department is true and missing_tests is empty. Never query slots when these two fields are absent.',
            size_bound='At most 5 fields; red_flag_term <= 200 characters; at most 20 missing tests, code <= 40 and name <= 200 characters. Oversize observations raise ValueError, never silently truncate.',
            irreversible='NO: read only.',
            failure=original[TARGET]['failure'] + ' Non-string/empty IDs raise ValueError. Oversize returns raise ValueError.')
    return result


def observation(name, value, version):
    if version not in ('v1', 'v2'):
        raise ValueError('version must be v1 or v2')
    if name != TARGET or value is None or version == 'v1':
        return value
    if (len(value.get('red_flag_term') or '') > 200 or len(value['missing_tests']) > 20
        or any(len(t['code']) > 40 or len(t['name']) > 200 for t in value['missing_tests'])):
        raise ValueError('criteria observation exceeds bounds; review manually')
    result = deepcopy(value)
    if result['red_flag_term'] or not result['right_department'] or result['missing_tests']:
        result.pop('band', None)
        result.pop('window_weeks', None)
    return result
